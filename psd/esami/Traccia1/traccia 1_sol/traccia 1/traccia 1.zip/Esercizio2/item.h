typedef void *Item;

Item inputItem();
void outputItem(Item);
int cmpItem(Item, Item);
Item cloneItem(Item);

Item randomItem();

void outputItemLen(Item, int);