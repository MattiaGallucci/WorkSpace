package it.unisa.parole;

public interface Iteratore<T> {
	T getNext();
	boolean hasNext();
}
