package it.unisa.parole;

public interface Strategy {
	void append(String str);
}
