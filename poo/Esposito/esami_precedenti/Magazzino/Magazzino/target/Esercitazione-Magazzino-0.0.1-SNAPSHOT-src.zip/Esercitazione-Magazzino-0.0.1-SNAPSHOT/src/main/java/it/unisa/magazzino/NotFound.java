package it.unisa.magazzino;

public class NotFound extends Exception {

	private static final long serialVersionUID = 1L;

	public NotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}

}
