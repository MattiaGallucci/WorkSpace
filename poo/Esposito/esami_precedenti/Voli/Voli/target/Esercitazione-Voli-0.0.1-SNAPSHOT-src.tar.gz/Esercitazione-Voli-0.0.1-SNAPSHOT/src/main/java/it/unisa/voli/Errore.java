package it.unisa.voli;

public class Errore extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6123884208761612938L;

	public Errore(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
