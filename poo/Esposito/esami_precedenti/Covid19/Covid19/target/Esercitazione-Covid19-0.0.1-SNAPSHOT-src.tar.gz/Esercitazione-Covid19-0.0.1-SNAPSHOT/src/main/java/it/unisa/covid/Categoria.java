package it.unisa.covid;

public enum Categoria {
	VettoreVirale,
	mRNA
}
